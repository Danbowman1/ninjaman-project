var world = [
    // [1, 1, 1, 1, 1],
    // [1, 0, 2, 3, 1],
    // [1, 2, 1, 2, 1],
    // [1, 2, 2, 2, 1],
    // [1, 2, 2, 2, 1],
    // [1, 2, 1, 2, 1],
    // [1, 2, 2, 2, 1],
    // [1, 2, 2, 2, 1],
    // [1, 2, 1, 2, 1],
    // [1, 3, 2, 3, 1],
    // [1, 1, 1, 1, 1],
];

var worldDict = {
    0: 'blank',
    1: 'wall',
    2: 'sushi',
    3: 'onigiri'
}

function drawWorld() {
    output = "";
    var worldWidth = 15
    var worldHeight = 15
    for (var row = 0; row < worldHeight; row++) {
        world.push([])
        output += "<div class = 'row'>"

        for (var col = 0; col < worldWidth; col++) {
            if(row == 1 || row == 14 || col ==0 || col==14) {
            output += "<div class = '" + worldDict[0] + "'></div>"
            world[row].push(0)
        } else {
            world[row].push(Math.floor(Math.random()*4))
            output += "<div class = '" + worldDict[world[row][col]] +"'></div>"
        }
    }
        output += "</div>"
    }

    document.getElementById('world').innerHTML =
        output;
}
drawWorld();

// NinjaMan Movement code 

var ninjaman = {
    x: 1,
    y: 1
}

function drawNinjaman() {
    document.getElementById('ninjaman').style.top = ninjaman.y * 40 + 'px'
    document.getElementById('ninjaman').style.left = ninjaman.x * 40 + 'px'
}
drawNinjaman()

document.onkeydown = function (e) {
    if (e.keyCode == 37) {
        if (world[ninjaman.y][ninjaman.x - 1] != 1) {
            ninjaman.x--;
        }
    }
    if (e.keyCode == 39) {
        if (world[ninjaman.y][ninjaman.x + 1] != 1) {
            ninjaman.x++;
        }
    }
    if (e.keyCode == 40) {
        if (world[ninjaman.y + 1][ninjaman.x] != 1) {
            ninjaman.y++;
        }
    }
    if (e.keyCode == 38) {
        if (world[ninjaman.y - 1][ninjaman.x] != 1) {
            ninjaman.y--;
        }
    }

    // NinjaMan eat
    world[ninjaman.y][ninjaman.x] = 0
    drawWorld()
    drawNinjaman()
}


// Make a way to keep score
// sushi = 10 onigiri = 5pts

// hacker challenges - create ghost that chase ninjaman